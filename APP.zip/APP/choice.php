<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Daftar</title>
</head>
    <body>
        <div class="container mt-5 text-center">
            <a href="index.php?controller=room" class="btn btn-danger btn-lg col-4 my-1 mx-1"><b>Tabel Ruangan</b></a>
            <a href="index.php?controller=admin" class="btn btn-primary btn-lg col-4 my-1 mx-1"><b>Tabel Admin</b></a>
            <a href="index.php?controller=user" class="btn btn-warning btn-lg col-4 my-1 mx-1"><b><font style="color: white;">Tabel User</font></b></a>
            <a href="index.php?controller=rent" class="btn btn-success btn-lg  col-4 my-1 mx-1"><b>Tabel Peminjaman</b></a>
        </div>
    </body>
</html>